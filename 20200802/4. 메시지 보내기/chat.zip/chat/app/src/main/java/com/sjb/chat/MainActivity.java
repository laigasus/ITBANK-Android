package com.sjb.chat;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.sjb.chat.db.DBConnAsync;

import java.util.concurrent.ExecutionException;

public class MainActivity extends AppCompatActivity {
    Button send_btn;
    EditText fromet, toet, messageet;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        send_btn = (Button)findViewById(R.id.btn_send);
        fromet = (EditText)findViewById(R.id.fromet);
        toet = (EditText)findViewById(R.id.toet);
        messageet = (EditText)findViewById(R.id.messageet);

        send_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DBConnAsync task = new DBConnAsync();
                task.execute("send",
                        "fromemail="+fromet.getText().toString()
                        +"&toemail="+toet.getText().toString()
                        +"&message="+messageet.getText().toString()
                );
            }
        });
    }
}