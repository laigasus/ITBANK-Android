package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.Display;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button showbtn;
    TextView toastTv;
    ImageView toastIv;
    View toastView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        showbtn = (Button)findViewById(R.id.showbtn);

        showbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast toast = new Toast(getApplicationContext());

                toastView = (View)View.inflate(
                        getApplicationContext(),
                        R.layout.toast1,
                        null);

                toastTv = (TextView)toastView.findViewById(R.id.toastText1);
                toastTv.setText("커스텀한 토스트");
                toastIv = (ImageView)toastView.findViewById(R.id.imageView1);

                toast.setView(toastView);
                toast.show();
            }
        });

    }
}