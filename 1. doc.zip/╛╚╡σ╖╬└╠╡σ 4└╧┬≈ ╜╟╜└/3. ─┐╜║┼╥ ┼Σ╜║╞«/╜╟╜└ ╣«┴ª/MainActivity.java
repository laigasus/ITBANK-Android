package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.Display;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button showbtn;
    EditText nameEt, numberEt, emailEt;
    TextView toastTv;
    ImageView toastIv;
    View toastView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nameEt = (EditText)findViewById(R.id.editname);
        numberEt = (EditText)findViewById(R.id.editnumber);
        emailEt = (EditText)findViewById(R.id.editemail);
        showbtn = (Button)findViewById(R.id.showbtn);

        showbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast toast = new Toast(getApplicationContext());

                toastView = (View)View.inflate(
                        getApplicationContext(),
                        R.layout.toast1,
                        null);

                toastTv = (TextView)toastView.findViewById(R.id.toastText1);
                toastIv = (ImageView)toastView.findViewById(R.id.imageView1);

                Display display = ((WindowManager) getSystemService(WINDOW_SERVICE))
                        .getDefaultDisplay();

                if(nameEt.getText().toString().isEmpty()) {
                    toastTv.setText("이름 입력하세요.");
                    toastIv.setImageResource(R.drawable.baseline_person_outline_black_18dp);
                }
                if(numberEt.getText().toString().isEmpty()) {
                    toastTv.setText("번호 입력하세요.");
                    toastIv.setImageResource(R.drawable.baseline_account_box_black_18dp);
                }
                if(emailEt.getText().toString().isEmpty()) {
                    toastTv.setText("이메일 입력하세요.");
                    toastIv.setImageResource(R.drawable.baseline_email_black_18dp);
                }
                toast.setView(toastView);
                toast.show();
            }
        });

    }
}