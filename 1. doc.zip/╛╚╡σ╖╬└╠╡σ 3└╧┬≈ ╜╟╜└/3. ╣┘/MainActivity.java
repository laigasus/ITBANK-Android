package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.Chronometer;
import android.widget.DatePicker;
import android.widget.MultiAutoCompleteTextView;
import android.widget.RadioButton;
import android.widget.RatingBar;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.util.Date;

public class MainActivity extends AppCompatActivity {
    Button volmax, volmute, ratemax, ratemin;
    SeekBar seekbar;
    RatingBar ratingbar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        volmax = (Button)findViewById(R.id.volmax);
        volmute = (Button)findViewById(R.id.volmute);
        ratemax = (Button)findViewById(R.id.ratemax);
        ratemin = (Button)findViewById(R.id.ratemin);
        seekbar = (SeekBar) findViewById(R.id.seekbar1);
        ratingbar = (RatingBar) findViewById(R.id.ratingbar1);

        volmax.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),
                        "현재 " + seekbar.getProgress() + "에서 MAX로 변경",
                        Toast.LENGTH_SHORT).show();
                seekbar.setProgress(100);
            }
        });

        seekbar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                Toast.makeText(getApplicationContext(),
                        "현재 " + seekbar.getProgress(),
                        Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        ratemax.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),
                        "현재 " + ratingbar.getRating() + "에서 MAX로 변경",
                        Toast.LENGTH_SHORT).show();
                ratingbar.setRating(5);
            }
        });

        ratingbar.setOnRatingBarChangeListener(
                new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float v, boolean b) {
                Toast.makeText(getApplicationContext(),
                        "현재 " + ratingbar.getRating(),
                        Toast.LENGTH_SHORT).show();
            }
        });
    }
}